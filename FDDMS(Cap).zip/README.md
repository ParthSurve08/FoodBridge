# FoodShare – Food Donation & Distribution Management System

A full-stack college capstone web application engineered with **Python (FastAPI), Data Structures (DS), and Relational Database Management Systems (MySQL)** in 3NF.

---

## 1. Project Architecture

* **Frontend**: React 18, Vite, Tailwind CSS, Lucide Icons, Multilingual i18n Engine (9 languages), Responsive UI (Mobile/Tablet/Desktop).
* **Backend**: Python 3.10+, FastAPI REST API, SQLAlchemy ORM, Pydantic v2 validation, JWT authentication with bcrypt/PBKDF2 password hashing, RBAC.
* **Database**: MySQL 8.0+ normalized to Third Normal Form (3NF) with foreign keys, CHECK constraints, and ACID transaction safety.
* **Data Structures (Python)**:
  * **Queue (`collections.deque`)**: O(1) FIFO volunteer delivery task dispatch.
  * **Priority Queue (`heapq` Min-Heap)**: O(log N) expiry prioritization for perishable food items.
  * **Inverted Index Hash Map (`dict`)**: O(1) keyword indexing for the integrated AI Chatbot Assistant.
  * **Logistics Graph (Adjacency List + Dijkstra)**: O((V + E) log V) shortest transit routing between donors, transit hubs, and NGO shelters.

---

## 2. Prerequisites

* **Node.js**: v18.0.0 or higher
* **npm**: v9.0.0 or higher
* **Python**: v3.10 or higher
* **MySQL Server**: v8.0 or higher

---

## 3. Database Initialization (MySQL)

1. Open your terminal or MySQL command line client and log in:
   ```bash
   mysql -u root -p
   ```

2. Execute the provided SQL schema script to create the database, 3NF tables, and demo seed data:
   ```bash
   mysql -u root -p < database/schema.sql
   ```

3. Verify that the tables and seed records are created:
   ```sql
   USE foodshare_db;
   SHOW TABLES;
   SELECT id, name, role, email FROM users;
   ```

---

## 4. Backend Setup (FastAPI & Python)

1. Navigate to the backend directory:
   ```bash
   cd backend
   ```

2. Create and activate a Python virtual environment:
   * **Linux / macOS**:
     ```bash
     python3 -m venv venv
     source venv/bin/activate
     ```
   * **Windows (Command Prompt / PowerShell)**:
     ```cmd
     python -m venv venv
     venv\Scripts\activate
     ```

3. Install the required Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Configure environment variables:
   * Copy the template:
     ```bash
     cp .env.example .env
     ```
   * Open `.env` and set your MySQL credentials:
     ```env
     DB_HOST=localhost
     DB_PORT=3306
     DB_USER=root
     DB_PASSWORD=your_mysql_password
     DB_NAME=foodshare_db
     SECRET_KEY=foodshare_jwt_secret_capstone_key_2026
     ```

5. Start the FastAPI backend server:
   ```bash
   uvicorn app.main:app --reload --port 8000
   ```
   * **Swagger Interactive Docs**: `http://localhost:8000/docs`
   * **ReDoc Documentation**: `http://localhost:8000/redoc`

---

## 5. Frontend Setup (React & Vite)

1. In a new terminal window, navigate to the frontend directory:
   ```bash
   cd frontend
   ```

2. Install frontend dependencies:
   ```bash
   npm install
   ```

3. Start the Vite local development server:
   ```bash
   npm run dev
   ```
   * **Application URL**: `http://localhost:5173`

---

## 6. Pre-Configured Demo Accounts

All pre-seeded demo accounts share the default password: `Password@123` (Admin: `Admin@123`).

| Role | Name | Email | Default Password |
| :--- | :--- | :--- | :--- |
| **Donor** | Chef Rajesh Verma | `donor@greenbites.com` | `Password@123` |
| **NGO** | Aarti Deshmukh | `ngo@annaseva.org` | `Password@123` |
| **Volunteer** | Karan Patil | `volunteer@foodshare.org` | `Password@123` |
| **Admin** | System Administrator | `admin@foodshare.org` | `Admin@123` |
